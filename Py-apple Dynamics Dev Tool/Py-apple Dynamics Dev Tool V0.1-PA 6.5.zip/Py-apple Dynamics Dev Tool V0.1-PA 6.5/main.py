import os

os.system("cls")
print("Py-apple Dynamics Dev Tool V0.1   2021.6.24 ")
print("菠萝四足机器人系统 快速配置工具 By 灯哥")

while True:
  print("""
==========数字指令表==========
1:烧录 Py-apple Dynamics 系统到主控中
2:列出主控目前所包含的 功能模块 和 文件
3:变更默认的 网页遥控器 为 航模遥控器遥控
4:装载串口控制功能(支持树莓派、OpenMV、Jetson NANO 等外部控制狗子)
5.恢复默认的 网页遥控器
6.在主控中装载 图形化编程 my_code.py 文件
==============================

输入对应的数字指令，按照提示开始配置机器人
""")
  user_input=input(">>")
  if user_input=="1":   #功能1
    com_num=input("输入 主控板串口号（如COM10就直接输入数字10）>>")
    ver_num=input("输入 机器人自由度(8自由度或12自由度，输入数字 8 或 12 )>>")
    print("正在抹除主控FLASH...")
    os.system("Scripts\\esptool --port COM"+com_num+" erase_flash")
    print("抹除主控FLASH完成")
    print("正在写入  Py-apple Dynamics 6.5 -- 8自由度版 系统文件")
    print("正在写入 MicroPython 系统...")
    os.system("Scripts\\esptool --chip esp32 --port COM"+com_num+" --baud 460800 write_flash -z 0x1000 MicroPythonFile\\esp32.bin")
    rootdir = '.\PA-Dynamics'
    file_list = os.listdir(rootdir)    #列出PA_DYNAMICS文件夹下文件
    for i in range(0, len(file_list)):
      path = file_list[i]
      print("正在写入:"+path)
      os.system("Scripts\\ampy --port COM"+com_num+" put PA-Dynamics\\"+path)
    os.system("Scripts\\ampy --port COM"+com_num+" reset")
    print("恭喜！烧录完成，现在可以：")
    print("第一步：按板子上的 EN 或 RST 复位系统")
    print("第二步：等待30秒后，搜索 ESP 开头 WIFI 并连接")
    print("第三步：浏览器访问以下地址：192.168.4.1")
    print("第四步：出现控制界面，接下来请按照教程 ,开始腿部校准，调试...")

  if user_input=="2":   #功能2
    com_num=input("输入 主控板串口号（如COM10就直接输入数字10）>>")
    os.system("Scripts\\ampy --port COM"+com_num+" ls")

  if user_input=="3" or user_input=="4":   #功能3和4
    print("必须已经烧录程序，并且完成在默认的-网页遥控器-中完成调中，机器狗行走调试后 才能使用此功能！\n没有完成调试请现在输入 n 退出，并进行调试")
    if input("已经完成调试？(y/n)>")=="y":
      com_num=input("输入 主控板串口号（如COM10就直接输入数字10）>>")
      if user_input=="3":
        print("变更默认的 网页遥控器 为 航模遥控器遥控,进行中...")
        os.system("Scripts\\ampy --port COM"+com_num+" put PA-Dynamics-rc-remote\\main.py")
        print("已完成，接下来请按照Github/B站 文档 视频教程连接配置航模遥控器")
      elif user_input=="4":
        print("装载串口控制功能(支持树莓派、OpenMV、Jetson NANO 等外部控制狗子,进行中...")
        os.system("Scripts\\ampy --port COM"+com_num+" put PA-Dynamics-uart-control\\main.py")
        print("已完成，接下来请按照Github/B站 文档 视频教程连接配置串口")
    else:
      print("检测到输入了n，退出此功能")

  if user_input=="5":   #功能5
    print("此功能将恢复默认的网页遥控器")
    if input("确认恢复？(y/n)>")=="y":
      com_num=input("输入 主控板串口号（如COM10就直接输入数字10）>>")
      print("恢复默认的网页遥控器,进行中...")
      os.system("Scripts\\ampy --port COM"+com_num+" put PA-Dynamics\\main.py")
      print("已完成...")
    else:
      print("检测到输入了n，退出此功能")
      
  if user_input=="6":   #功能6 
    print("使用此功能，请首先把来自积木化编程 mpython 的文件命名为 my_code.py 放到 Block_Pro 文件夹")
    print("接着，确认开始后，软件将自动将 my_code.py 写入，并自动屏蔽网页遥控功能，下次按 RST/EN 复位后，直接执行 my_code.py内容")
    print("如果你想恢复为网页遥控器，请重启软件并选择 功能5")
    if input("确认开始？(y/n)>")=="y":
      com_num=input("输入 主控板串口号（如COM10就直接输入数字10）>>")
      print("烧录图形化积木编程文件,进行中...")
      os.system("Scripts\\ampy --port COM"+com_num+" put Block_Pro\\my_code.py")
      os.system("Scripts\\ampy --port COM"+com_num+" put PA-Dynamics-block-prog\\main.py")
      print("已完成...")
    else:
      print("检测到输入了n，退出此功能")
