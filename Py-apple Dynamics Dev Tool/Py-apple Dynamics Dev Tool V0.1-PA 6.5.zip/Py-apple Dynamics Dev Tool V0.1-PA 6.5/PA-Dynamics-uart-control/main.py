import _thread
import padog
import time
from machine import Timer
from machine import UART
from padog import g,m
#
from machine import Pin


#run_mode=1：串口 （高速--巡线等）
#run_mode=2：串口 （低速--颜色识别等）

run_mode=1

uart6=UART(2,115200)
t = Timer(1)

def UART_Run(t):
  command=""
  if uart6.any():
    read = uart6.read(1).decode('gbk')
    while read != '/':
      command = command + read
      read = uart6.read(1).decode('gbk')
    if(command != "1/" ) and command!="":
      try:
        exec(command)
        print("exec:",command)
      except:
        print("execerr:",command)
    command = ""

    
    
def serial_run_loop():
  while True:
    padog.mainloop()

def loop(t):
  padog.mainloop()
  


elif run_mode==1:
  t.init(period=50,mode=Timer.PERIODIC,callback=UART_Run)
  padog.gesture(0,0,padog.in_y)
  padog.speed=0.045
  serial_run_loop()
elif run_mode==2:
  t.init(period=10,mode=Timer.PERIODIC,callback=UART_Run)
  padog.gesture(0,0,padog.in_y)
  padog.speed=0.045
  serial_run_loop()

