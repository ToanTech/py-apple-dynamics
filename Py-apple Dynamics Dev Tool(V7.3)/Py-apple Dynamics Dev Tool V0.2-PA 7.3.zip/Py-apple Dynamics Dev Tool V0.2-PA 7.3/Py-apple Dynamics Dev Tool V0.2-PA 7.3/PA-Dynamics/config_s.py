
init_1h=90

init_1s=90

init_2h=90

init_2s=90

init_3h=90

init_3s=90

init_4h=90

init_4s=90

l1=80

l2=69

l=142

b=92.8

w=108

speed=0.05

h=30

Kp_H=0.06

pit_Kp_G=0.04

pit_Kd_G=0.6

rol_Kp_G=0.04

rol_Kd_G=0.35

tran_mov_kp=0.1

CC_M=0

walk_h=50

walk_speed=0.02

ma_case=0

trot_cg_f=4

trot_cg_b=4

trot_cg_t=2

in_y=17



