Blockly.Blocks['shake_shake'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("摇头");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(20);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['nod_nod'] = {
    init: function() {
        this.appendDummyInput()
            .appendField("点头");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(20);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['show_circle'] = {
    init: function() {
        this.appendValueInput("NAME1")
            .setCheck("Number")
            .appendField("扭动次数：");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(230);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['gesture'] = {
    init: function() {
        this.appendValueInput("NAME1")
            .setCheck("Number")
            .appendField("俯仰轴角度：");
        this.appendValueInput("NAME2")
            .setCheck("Number")
            .appendField("滚转轴角度：");
        this.appendValueInput("NAME3")
            .setCheck("Number")
            .appendField("前后平移量：");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(120);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['gait'] = {
    init: function() {
        this.appendValueInput("NAME1")
            .setCheck("Number")
            .appendField("步态设置：");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(330);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['stable'] = {
    init: function() {
        this.appendValueInput("NAME1")
            .setCheck("Boolean")
            .appendField("是否打开自稳定");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(20);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['height'] = {
    init: function() {
        this.appendValueInput("NAME1")
            .setCheck("Number")
            .appendField("高度值：");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(20);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
Blockly.Blocks['move'] = {
    init: function() {
        this.appendValueInput("NAME1")
            .setCheck("Number")
            .appendField("速度设置：");
        this.appendValueInput("NAME2")
            .setCheck("Number")
            .appendField("方向设置1：");
        this.appendValueInput("NAME3")
            .setCheck("Number")
            .appendField("方向设置2：");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(120);
        this.setTooltip('');
        this.setHelpUrl('http://www.example.com/');
    }
};
