Blockly.Python['shake_shake'] = function(block) {
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['import padog'] = 'import padog,time';
    var code = 'padog.gesture(0,30,0),time.sleep(0.3);padog.gesture(0,-30,0);time.sleep(0.3)'+'\n';
    return code;
};
Blockly.Python['nod_nod'] = function(block) {
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['import padog'] = 'import padog,time';
    var code = 'padog.gesture(10,0,0);time.sleep(0.3);padog.gesture(-10,0,0);time.sleep(0.3)\n';
    return code;
};
Blockly.Python['show_circle'] = function(block) {
    var value_name1 = Blockly.Python.valueToCode(block, 'NAME1', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['import padog'] = 'import padog';
    var code = 'padog.show_circle('+value_name1+')\n';
    return code;
};
Blockly.Python['gesture'] = function(block) {
    var value_name1 = Blockly.Python.valueToCode(block, 'NAME1', Blockly.Python.ORDER_ATOMIC);
    var value_name2 = Blockly.Python.valueToCode(block, 'NAME2', Blockly.Python.ORDER_ATOMIC);
    var value_name3 = Blockly.Python.valueToCode(block, 'NAME3', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['import padog'] = 'import padog';
    var code = 'padog.gesture('+value_name1+','+value_name2+','+value_name3+')\n';
    return code;
};
Blockly.Python['gait'] = function(block) {
    var value_name1 = Blockly.Python.valueToCode(block, 'NAME1', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['import padog'] = 'import padog';
    var code = 'padog.gait('+value_name1+')\n';
    return code;
};
Blockly.Python['stable'] = function(block) {
    var value_name1 = Blockly.Python.valueToCode(block, 'NAME1', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['import padog'] = 'import padog';
    var code = 'padog.stable('+value_name1+')\n';
    return code;
};
Blockly.Python['height'] = function(block) {
    var value_name1 = Blockly.Python.valueToCode(block, 'NAME1', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['import padog'] = 'import padog';
    var code = 'padog.height('+value_name1+')\n';
    return code;
};
Blockly.Python['move'] = function(block) {
    var value_name1 = Blockly.Python.valueToCode(block, 'NAME1', Blockly.Python.ORDER_ATOMIC);
    var value_name2 = Blockly.Python.valueToCode(block, 'NAME2', Blockly.Python.ORDER_ATOMIC);
    var value_name3 = Blockly.Python.valueToCode(block, 'NAME3', Blockly.Python.ORDER_ATOMIC);
    // TODO: Assemble Python into code variable.
    Blockly.Python.definitions_['import padog'] = 'import padog';
    var code = 'padog.move('+value_name1+','+value_name2+','+value_name3+')\n';
    return code;
};
