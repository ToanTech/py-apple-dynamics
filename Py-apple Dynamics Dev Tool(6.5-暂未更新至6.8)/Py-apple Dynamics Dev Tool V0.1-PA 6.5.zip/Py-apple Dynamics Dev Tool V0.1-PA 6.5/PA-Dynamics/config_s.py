init_1h=90

init_1s=90

init_2h=90

init_2s=90

init_3h=90

init_3s=90

init_4h=90

init_4s=90

l1=80

l2=69

l=142

b=92.80001

w=108

speed=0.035

h=45

Kp_H=0.06

Kp_G=0.06

ma_case=0

in_pit=0

in_rol=0

in_y=0

vmc_mode=0

CG_X=0
CG_Y=30
walk_h=60
walk_speed=0.015
trot_cg_f=4
trot_cg_b=8
trot_cg_t=0






