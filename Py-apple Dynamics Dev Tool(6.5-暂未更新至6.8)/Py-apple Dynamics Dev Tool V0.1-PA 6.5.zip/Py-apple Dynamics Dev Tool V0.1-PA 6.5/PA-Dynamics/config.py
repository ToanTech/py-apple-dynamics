#=============Wifi设置=============
#do_connect_STA('Toan','Toan123456')  #WIFI账号密码
do_connect_AP() 
#=============步态参数=============
Ts=1   #周期
faai=0.5   #占空比
pit_max_ang=20   #设定俯仰轴最大限制角度
rol_max_ang=20   #设定滚转轴最大限制角度
xs_max=80        #设定最大x轴移动角度




















