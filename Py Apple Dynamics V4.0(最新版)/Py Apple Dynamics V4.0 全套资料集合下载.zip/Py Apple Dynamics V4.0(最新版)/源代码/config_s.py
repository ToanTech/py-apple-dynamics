
init_1h=77

init_1s=89

init_2h=84

init_2s=102

init_3h=83

init_3s=103

init_4h=90

init_4s=74

l1=80

l2=62.5

l=202

b=105

w=132

speed=0.04

h=50

Kp_H=0.03

Kp_G=0.04

ma_case=0



